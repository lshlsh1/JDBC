package com.util;

import java.sql.Connection;
import java.sql.DriverManager;

public class DBConn
{
	private static Connection DBConn;

	public static Connection getConnection()
	{
		if (DBConn == null)
		{
			try
			{
				String url = "jdbc:oracle:thin:@localhost:1521:xe";
				String user = "scott";
				String pwd = "tiger";

				Class.forName("oracle.jdbc.driver.OracleDriver");

				DBConn = DriverManager.getConnection(url, user, pwd);

			} catch (Exception e)
			{
				System.out.println(e.toString());
			}
		}

		return DBConn;
	}

	public static Connection getConnection (String url, String user, String pwd)
	{
		if (DBConn == null)
		{
			try
			{
				Class.forName("orcle.jdbc.driver.oracleDriver");
				DBConn = DriverManager.getConnection(url,user,pwd);
			} catch (Exception e)
			{
				System.out.println(e.toString());			
			}
		}
		return DBConn;

	}

	public static void close()
	{
		if (DBConn != null)
		{
			try
			{
				if (!DBConn.isClosed())
					DBConn.close();
			} catch (Exception e)
			{
				System.out.println(e.toString());
			}
		}

		DBConn = null;
	}

}
