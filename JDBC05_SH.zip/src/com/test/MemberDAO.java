package com.test;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.util.DBConn;

public class MemberDAO
{
	
	private Connection conn;
	
	// 데이터베이스 연결 담당 메소드
	public Connection connection() throws ClassNotFoundException, SQLException
	{
		conn = DBConn.getConnection();
		return conn;
	}
	
	// 1.정보 입력 메소드
	public int add(MemberDTO dto) throws SQLException
	{
		int result = 0;
		Statement stmt = conn.createStatement();
		String sql = String.format("INSERT INTO TBL_EMP (EMP_ID, EMP_NAME, SSN, IBSADATE, CITY_ID, TEL, BUSEO_ID, JIKWI_ID, BASICPAY, SUDANG) " + 
				"VALUES (EMPSEQ.NEXTVAL, '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s')"
				, dto.getEmp_name(), dto.getSsn(), dto.getIbsadate(), dto.getCity_id()
				, dto.getTel(), dto.getBuseo_id(), dto.getJikwi_id(), dto.getBasicpay(), dto.getSudang());
		result = stmt.executeUpdate(sql);
		stmt.close();
		return result;
	}

	// 2.정보 출력 메소드
	
	// 2-1. 사번 정렬
	public ArrayList<MemberDTO> namelists() throws SQLException
	{
		ArrayList<MemberDTO> result = new ArrayList<MemberDTO>();
		Statement stmt = conn.createStatement();
		String sql = "SELECT EMP_ID E, EMP_NAME E, SSN E, IBSADATE E, CITY_LOC C, TEL E, BUSEO_NAME B, JIKWI_NAME J , BASICPAY E, SUDANG E, (BASICPAY+SUDANG) E" + 
				"FROM TBL_EMP E, TBL_CITY C , TBL_BUSEO B, TBL_JIKWI J" + 
				"WHERE E.CITY_ID = C.CITY_ID(+)" + 
				"  AND E.BUSEO_ID = B.BUSEO_ID(+)" + 
				"  AND E.JIKWI_ID = J.JIKWI_ID(+)" + 
				"ORDER BY EMP_ID;";
		
		ResultSet rs = stmt.executeQuery(sql);
		
		while (rs.next())
		{
			MemberDTO dto = new MemberDTO();
			dto.setEmp_id(rs.getInt("EMP_ID"));
			dto.setEmp_name(rs.getString("EMP_NAME"));
			dto.setSsn(rs.getString("SSN"));
			dto.setIbsadate(rs.getString("IBSADATE"));
			dto.setCity_loc(rs.getString("CITY_LOC"));
			dto.setTel(rs.getString("TEL"));
			dto.setBuseo_name(rs.getString("BUESO_NAME"));
			dto.setJikwi_name(rs.getString("JIKWI_NAME"));
			dto.setBasicpay(rs.getInt("BASICPAY"));
			dto.setSudang(rs.getInt("SUDANG"));
			dto.setPay(rs.getInt(11));
		
			result.add(dto);
		}
		rs.close();
		stmt.close();
		
		return result;
	}
	// 2-2 이름 정렬
	// 2-3 부서 정렬
	public ArrayList<MemberDTO> buseolists() throws SQLException
	{
		ArrayList<MemberDTO> result = new ArrayList<MemberDTO>();
		Statement stmt = conn.createStatement();
		String sql = "SELECT * FROM TBL_EMP ORDER BY BUSEO_ID";
		ResultSet rs = stmt.executeQuery(sql);
		while (rs.next())
		{
			MemberDTO dto = new MemberDTO();
			dto.setEmp_id(rs.getInt("EMP_ID"));
			dto.setEmp_name(rs.getString("EMP_NAME"));
			dto.setSsn(rs.getString("SSN"));
			dto.setIbsadate(rs.getString("IBSADATE"));
			dto.setCity_id(rs.getInt("CITY_ID"));
			dto.setTel(rs.getString("TEL"));
			dto.setBuseo_id(rs.getInt("BUESO_ID"));
			dto.setJikwi_id(rs.getInt("JIKWI_ID"));
			dto.setBasicpay(rs.getInt("BASICPAY"));
			dto.setSudang(rs.getInt("SUDANG"));
		
			result.add(dto);
		}
		rs.close();
		stmt.close();
		
		return result;
	}
	// 2-4 직위 정렬
	//jikwilists()
	public ArrayList<MemberDTO> jikwilists() throws SQLException
	{
		ArrayList<MemberDTO> result = new ArrayList<MemberDTO>();
		Statement stmt = conn.createStatement();
		String sql = "SELECT * FROM TBL_EMP ORDER BY JIKWI_ID";
		ResultSet rs = stmt.executeQuery(sql);
		while (rs.next())
		{
			MemberDTO dto = new MemberDTO();
			dto.setEmp_id(rs.getInt("EMP_ID"));
			dto.setEmp_name(rs.getString("EMP_NAME"));
			dto.setSsn(rs.getString("SSN"));
			dto.setIbsadate(rs.getString("IBSADATE"));
			dto.setCity_id(rs.getInt("CITY_ID"));
			dto.setTel(rs.getString("TEL"));
			dto.setBuseo_id(rs.getInt("BUESO_ID"));
			dto.setJikwi_id(rs.getInt("JIKWI_ID"));
			dto.setBasicpay(rs.getInt("BASICPAY"));
			dto.setSudang(rs.getInt("SUDANG"));
		
			result.add(dto);
		}
		rs.close();
		stmt.close();
		
		return result;
	}
	
	
	// 2-5 급여 내림차순 정렬
	//moneylists()
	public ArrayList<MemberDTO> moneylists() throws SQLException
	{
		ArrayList<MemberDTO> result = new ArrayList<MemberDTO>();
		Statement stmt = conn.createStatement();
		String sql = "SELECT * FROM TBL_EMP ORDER BY (BASICPAY+SUDANG) DESC";
		ResultSet rs = stmt.executeQuery(sql);
		while (rs.next())
		{
			MemberDTO dto = new MemberDTO();
			dto.setEmp_id(rs.getInt("EMP_ID"));
			dto.setEmp_name(rs.getString("EMP_NAME"));
			dto.setSsn(rs.getString("SSN"));
			dto.setIbsadate(rs.getString("IBSADATE"));
			dto.setCity_id(rs.getInt("CITY_ID"));
			dto.setTel(rs.getString("TEL"));
			dto.setBuseo_id(rs.getInt("BUESO_ID"));
			dto.setJikwi_id(rs.getInt("JIKWI_ID"));
			dto.setBasicpay(rs.getInt("BASICPAY"));
			dto.setSudang(rs.getInt("SUDANG"));
		
			result.add(dto);
		}
		rs.close();
		stmt.close();
		
		return result;
	}


	// 3. 직원 검색 메소드
	// 3-1 사번 검색
	public ArrayList<MemberDTO> idsearchlists(int emp_id) throws SQLException
	{
		ArrayList<MemberDTO> result = new ArrayList<MemberDTO>();
		Statement stmt = conn.createStatement();
		String sql = String.format("SELECT * FROM TBL_EMP WHERE EMP_ID=%d", emp_id);
		ResultSet rs = stmt.executeQuery(sql);
		while (rs.next())
		{
			MemberDTO dto = new MemberDTO();
			dto.setEmp_id(rs.getInt("EMP_ID"));
			dto.setEmp_name(rs.getString("EMP_NAME"));
			dto.setSsn(rs.getString("SSN"));
			dto.setIbsadate(rs.getString("IBSADATE"));
			dto.setCity_id(rs.getInt("CITY_ID"));
			dto.setTel(rs.getString("TEL"));
			dto.setBuseo_id(rs.getInt("BUESO_ID"));
			dto.setJikwi_id(rs.getInt("JIKWI_ID"));
			dto.setBasicpay(rs.getInt("BASICPAY"));
			dto.setSudang(rs.getInt("SUDANG"));
		
			result.add(dto);
		}
		rs.close();
		stmt.close();
		
		return result;
	}
	
	// 3-2 이름 검색
	//namesearchlists()
	
	// 3-3 부서 검색
	//buseosearchlist()
	
	// 3-4 직위 검색
	//jikwisearchlist()
	
	// 4. 직원 정보 수정 메소드
	//modify()
	public int modify(MemberDTO dto) throws SQLException
	{
		int result=0;
		Statement stmt = conn.createStatement();
		String sql = String.format("UPDATE TBL_EMP " 
				+ "SET EMP_NAME='%s', SSN='%s', IBSADATE='%s', CITY_ID='%d', TEL='%s', BUSEO_ID='%d', JIKWI_ID='%d', BASICPAY='%d', SUDANG='%d'"
				+ "WHERE EMP_ID='%d'"
				, dto.getEmp_name(), dto.getSsn(), dto.getIbsadate(), dto.getCity_id()
				, dto.getTel(), dto.getBuseo_id(), dto.getJikwi_id(), dto.getBasicpay(), dto.getSudang(), dto.getEmp_id());
		result = stmt.executeUpdate(sql);
		stmt.close();
		
		return result;
	}
	
	// 5. 직원 정보 삭제 메소드
	//remove()
	public int remove(int emp_id) throws SQLException
	{
		int result =0;
		Statement stmt = conn.createStatement();
		String sql = String.format("DELETE FROM TBL_SCORE WHERE EMP_ID=%d", emp_id);
		result = stmt.executeUpdate(sql);
		stmt.close();
		return result;
		
	}

	// 지역정보를 숫자로 바꾸는 메소드
	public int city(String city_loc) throws SQLException
	{
		int city_id = 0;
		Statement stmt = conn.createStatement();
		String sql = String.format("SELECT CITY_ID FROM TBL_CITY WHERE CITY_LOC='%s'", city_loc);
		ResultSet rs = stmt.executeQuery(sql);
		
		while(rs.next())
			city_id = rs.getInt(1);
	
		rs.close();
		stmt.close();
		
		return city_id;		
	}
	
	// 부서정보를 숫자로 바꾸는 메소드
	public int buseo(String buseo_name) throws SQLException
	{
		int buseo_id = 0;
		Statement stmt = conn.createStatement();
		String sql = String.format("SELECT BUSEO_ID FROM TBL_BUSEO WHERE BUSEO_NAME='%s'", buseo_name);
		ResultSet rs = stmt.executeQuery(sql);
		
		while(rs.next())
			buseo_id = rs.getInt(1);
		
		rs.close();
		stmt.close();
		return buseo_id;		
	}
	
	// 직위정보를 숫자로 바꾸는 메소드
	public int jikwi(String jikwi_name) throws SQLException
	{
		int jikwi_id = 0;
		Statement stmt = conn.createStatement();
		String sql = String.format("SELECT JIKWI_ID FROM TBL_JIKWI WHERE JIKWI_NAME='%s'", jikwi_name);
		ResultSet rs = stmt.executeQuery(sql);
		
		while(rs.next())
			jikwi_id = rs.getInt(1);
			
		rs.close();
		stmt.close();
		return jikwi_id;		
	}
	
	// 직위 정보로 기본급을 출력하는 메소드
	public int basicpay(int jikwi_id) throws SQLException
	{
		int basicpay = 0;
		Statement stmt = conn.createStatement();
		String sql = String.format("SELECT MIN_BASICPAY FROM TBL_JIKWI WHERE JIKWI_ID=%d", jikwi_id);
		ResultSet rs = stmt.executeQuery(sql);
		
		while(rs.next())
			basicpay = rs.getInt(1);
		
		rs.close();
		stmt.close();
		return basicpay;
	}
	
	//리스트 출력
	public ArrayList<String> getList(String table, String column)
	{
		ArrayList<String> list = new ArrayList<String>();
		
		try
		{
			Statement stmt = conn.createStatement();
			String sql = String.format("Select * from %s", table);
			
			ResultSet rs = stmt.executeQuery(sql);
			
			while (rs.next())
			{
				list.add(rs.getString(column));
			}
		}catch (Exception e)
		{
			System.out.println(e.toString());
		}
		
		return list;
	}
	
	
	//데이터베이스 연결 종료 담당 메소드
	public void close() throws SQLException
	{
		DBConn.close();
	}
	
}	
