package com.test;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import com.util.DBConn;

public class MemberDAO
{
	private Connection conn;
	
	MemberDAO()
	{
		conn = DBConn.getConnection();
	}
	// 카운트
	public int count()
	{
		int result=0;
		
		try
		{
			Statement stmt = conn.createStatement();
			String sql = "SELECT COUNT(*) AS COUNT FROM TBL_EMP";
			
			
			ResultSet rs = stmt.executeQuery(sql);
			
			while (rs.next())
			{
				result = rs.getInt("COUNT");
			}
		} catch (Exception e)
		{
			System.out.println(e.toString());
		}
		
		return result;
	}
	
	
	// 직원 전체 출력
	public ArrayList<MemberDTO> selectAll(String orderBy)
	{
		ArrayList<MemberDTO> list = new ArrayList<MemberDTO>();
		
		try
		{
			
			Statement stmt = conn.createStatement();
			String sql = String.format("SELECT EMP_ID, EMP_NAME, SSN, IBSADATE, CITY_LOC, TEL, BUSEO_NAME, JIKWI_NAME, BASICPAY, SUDANG, NVL(BASICPAY*12,0)+NVL(SUDANG,0) AS PAY FROM TBL_EMP E JOIN TBL_CITY C ON E.CITY_ID=C.CITY_ID JOIN TBL_BUSEO B ON E.BUSEO_ID = B.BUSEO_ID JOIN TBL_JIKWI J ON E.JIKWI_ID = J.JIKWI_ID ORDER BY %s", orderBy);			
			
			ResultSet rs = stmt.executeQuery(sql);
			
			while (rs.next())
			{
				MemberDTO dto = new MemberDTO();
				
				dto.setEmpId(rs.getInt("EMP_ID"));
				dto.setEmpName(rs.getString("EMP_NAME"));
				dto.setSsn(rs.getString("SSN"));
				dto.setIbsadate(rs.getString("IBSADATE"));
				dto.setCityLoc(rs.getString("CITY_LOC"));
				dto.setTel(rs.getString("TEL"));
				dto.setBuseoName(rs.getString("BUSEO_NAME"));
				dto.setJikwiName(rs.getString("JIKWI_NAME"));
				dto.setBasicPay(rs.getInt("BASICPAY"));
				dto.setSudang(rs.getInt("SUDANG"));
				dto.setPay(rs.getInt("PAY"));
				
				list.add(dto);
			}
		} catch (Exception e)
		{
			System.out.println(e.toString());
		}

		return list;
	}
	
	// 입력
	public int insert(MemberDTO dto)
	{
		int result=0;
		
		try
		{
			Statement stmt = conn.createStatement();
			String sql = String.format("INSERT INTO TBL_EMP (EMP_ID, EMP_NAME, SSN, IBSADATE, CITY_ID, TEL, BUSEO_ID, JIKWI_ID, BASICPAY, SUDANG) VALUES (EMPSEQ.NEXTVAL, '%s', '%s', '%s', %d, '%s', %d, %d, %d , %d)", dto.getEmpName(), dto.getSsn(), dto.getIbsadate(), dto.getCityId(), dto.getTel(), dto.getBuseoId(), dto.getJikwiID(), dto.getBasicPay(), dto.getSudang());
			
			result = stmt.executeUpdate(sql);
		} catch (Exception e)
		{
			System.out.println(e.toString());
		}
		return result;
	}
	
	// 입력 헬퍼 메서드(부서, 지역, 직급 리스트 출력 헬퍼메서드)
	public ArrayList<String> getList(String table, String column)
	{
		ArrayList<String> list = new ArrayList<String>();
		
		try
		{
			Statement stmt = conn.createStatement();
			String sql = String.format("SELECT * FROM %s", table);
			
			ResultSet rs = stmt.executeQuery(sql);
			
			while (rs.next())
			{
				list.add(rs.getString(column));
			}
		} catch (Exception e)
		{
			System.out.println(e.toString());
		}
		
		return list;
	}
	
	// 입력 헬퍼 메서드(ex) '경기'를 입력받아 해당 ID를 리턴해줌)
	public int stringToInt(String table, String columnId, String columnName, String name)
	{
		int result = 0;
		try
		{
			Statement stmt = conn.createStatement();
			String sql = String.format("SELECT %s FROM %s WHERE %s = '%s'", columnId, table, columnName, name);
			ResultSet rs = stmt.executeQuery(sql);
			
			while (rs.next())
			{
				result = rs.getInt(columnId);
			}
		} catch (Exception e)
		{
			System.out.println(e.toString());
		}
		return result;
	}
	
	// 검색 출력 
	public ArrayList<MemberDTO> select(String column, String value)
	{
		ArrayList<MemberDTO> list = new ArrayList<MemberDTO>();
		
		try
		{
			Statement stmt = conn.createStatement();
			String sql = String.format("SELECT E.EMP_ID, E.EMP_NAME, E.SSN, E.IBSADATE, C.CITY_LOC, C.CITY_ID, E.TEL, B.BUSEO_NAME, B.BUSEO_ID, J.JIKWI_NAME, J.JIKWI_ID, E.BASICPAY, E.SUDANG, NVL(E.BASICPAY*12,0)+NVL(E.SUDANG,0) AS PAY\r\n" + 
					"FROM TBL_EMP E JOIN TBL_CITY C ON E.CITY_ID=C.CITY_ID \r\n" + 
					"               JOIN TBL_BUSEO B ON E.BUSEO_ID = B.BUSEO_ID\r\n" + 
					"               JOIN TBL_JIKWI J ON E.JIKWI_ID = J.JIKWI_ID\r\n" + 
					"WHERE %s = '%s'", column, value);
			
			ResultSet rs = stmt.executeQuery(sql);
			
			while (rs.next())
			{
				MemberDTO dto = new MemberDTO();
				
				dto.setEmpId(rs.getInt("EMP_ID"));
				dto.setEmpName(rs.getString("EMP_NAME"));
				dto.setSsn(rs.getString("SSN"));
				dto.setIbsadate(rs.getString("IBSADATE"));
				dto.setCityLoc(rs.getString("CITY_LOC"));
				dto.setCityId(rs.getInt("CITY_ID"));
				dto.setTel(rs.getString("TEL"));
				dto.setBuseoName(rs.getString("BUSEO_NAME"));
				dto.setBuseoId(rs.getInt("BUSEO_ID"));
				dto.setJikwiName(rs.getString("JIKWI_NAME"));
				dto.setJikwiID(rs.getInt("JIKWI_ID"));
				dto.setBasicPay(rs.getInt("BASICPAY"));
				dto.setSudang(rs.getInt("SUDANG"));
				dto.setPay(rs.getInt("PAY"));
				
				
				list.add(dto);
			}
		} catch (Exception e)
		{
			System.out.println(e.toString());
		}
		
		return list;
	}
	
	// 삭제
	public int delete(int empId)
	{
		int result = 0;
		
		try
		{
			Statement stmt = conn.createStatement();
			String sql = String.format("DELETE FROM TBL_EMP WHERE EMP_ID = %d", empId);
			
			result = stmt.executeUpdate(sql);
		} catch (Exception e)
		{
			System.out.println(e.toString());
		}
		
		return result;
	}
	

	// 업데이트
	public int update(MemberDTO dto)
	{
		int result=0;
		
		try
		{
			Statement stmt = conn.createStatement();
			String sql = String.format("UPDATE TBL_EMP SET EMP_NAME = '%s', CITY_ID = %d, TEL = '%s', BUSEO_ID = %d, JIKWI_ID = %d, BASICPAY = %d, SUDANG = %d WHERE EMP_ID = %d", dto.getEmpName(), dto.getCityId(), dto.getTel(), dto.getBuseoId(), dto.getJikwiID(), dto.getBasicPay(), dto.getSudang(), dto.getEmpId());
			result = stmt.executeUpdate(sql);
		} catch (Exception e)
		{
			System.out.println(e.toString());
		}
		
		return result;
	}
	
	// 연결 종료
	public void close()
	{	
		try
		{
			conn.close();			
		} catch (Exception e)
		{
			System.out.println(e.toString());
		}
	}
}
