/*==============================
 * 		MemberMain.java
===============================*/

/*
 * ○ 문제
 * TBL_MEMBER 테이블을 활용하여
 * 이름과 전화번호를 여러 건 입력받고, 전체 출력하는 프로그램을 구현한다
 * 단, 데이터베이스 연동이 이루어져야 하고
 * MemberDAO, MemberDTO 클래스를 활용해야 한다.
 * 
 * 실행 예)
 * 
 * 이름 전화번호 입력(1) : 전훈의 010-1111-1111
 * 회원 정보 입력 완료~!!!!
 * 이름 전화번호 입력(2) : 유진석 010-2222-2222
 * 회원 정보 입력 완료~!!!!
 * 이름 전화번호 입력(3) : 최보라 010-3333-3333
 * 회원 정보 입력 완료~!!!~
 * 이름 전화번호 입력(4) : .
 * 
 * -----------------------------------------------
 * 전체 회원수 : 3명
 * -----------------------------------------------
 * 번호		이름		전화번호
 * 1		전훈의		010-1111-1111
 * 2		유진석		010-2222-2222
 * 3		최보라		010-3333-3333
 * -----------------------------------------------
 * */

package com.test;

import java.sql.SQLException;
import java.util.Scanner;

import com.util.DBConn;

public class MemberMain
{
	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);
		
		try
		{
			MemberDAO dao = new MemberDAO();
			
			int count = dao.count();
					
			do
			{
				System.out.printf("이름 전화번호 입력 (%d) : ", (++count));
				String name = sc.next();
				
				//반복의 조건을 무너뜨리는 코드 구성
				if (name.equals("."))
					break;
				
				String tel = sc.next();
				
				// MemberDTO 객체 구성
				MemberDTO dto = new MemberDTO();
				dto.setName(name);
				dto.setTel(tel);
				//sid는 시퀀스로 자동 입력되는 값 
				
				//데이터베이스에 데이터를 입력하는 메소드 호출
				int result = dao.add(dto);
				
				if (result > 0)
					System.out.println("회원 정보 입력 완료~!!!!");		
					
			} while (true);
			
		
			//.을 찍고 반복문 밖으로 
			
			System.out.println("-----------------------------------------------");
			System.out.printf("전체 회원수 : %s명 \n", dao.count());
			System.out.println("-----------------------------------------------");
			System.out.println("번호 이름 전화번호");
			
			for (MemberDTO obj : dao.lists())
			{
				System.out.printf("%3s %7s %12s \n"
						, obj.getSid(), obj.getName(), obj.getTel());
			}
			System.out.println("-----------------------------------------------");
			
		} catch (Exception e)
		{
			System.out.println(e.toString());
		}
		finally
		{
			try
			{
				DBConn.close();
				System.out.println("데이터베이스 연결 닫힘~!!!!");
				System.out.println("프로그램 종료됨");
				
			} catch (SQLException e)
			{
				System.out.println(e.toString());
			}
		}
		
	}	

		
}

/*
이름 전화번호 입력 (2) : 유진석 010-2222-2222
회원 정보 입력 완료~!!!!
이름 전화번호 입력 (3) : 최보라 010-3333-3333
회원 정보 입력 완료~!!!!
이름 전화번호 입력 (4) : .
-----------------------------------------------
전체 회원수 : 3명 
-----------------------------------------------
번호 이름 전화번호
 14     전훈의 010-1111-1111 
 15     유진석 010-2222-2222 
 16     최보라 010-3333-3333 
-----------------------------------------------
데이터베이스 연결 닫힘~!!!!
프로그램 종료됨
*/
