package com.test;

import java.util.ArrayList;
import java.util.Scanner;

public class MemberProcess
{	
	MemberDAO dao;
	
	MemberProcess()
	{
		// 데이터베이스 연결
		dao = new MemberDAO();
	}
	
	// 직원 정보 입력
	public void insert()
	{	
		Scanner sc = new Scanner(System.in);
		MemberDTO dto = new MemberDTO();
		// EMP_ID, EMP_NAME, SSN, IBSADATE, CITY_ID, TEL, BUSEO_ID, JIKWI_ID, BASICPAY, SUDANG
		System.out.println();
		System.out.println("---------------------------- 직원 정보 입력 ------------------------------");
		System.out.println();
		System.out.print("이름 : ");
		dto.setEmpName(sc.next());
		
		System.out.print("주민등록번호(yymmdd-nnnnnnn) : ");
		dto.setSsn(sc.next());
		
		System.out.print("입사일(yyyy-mm-dd) : ");
		dto.setIbsadate(sc.next());
		
		System.out.print("지역(" + printList("TBL_CITY", "CITY_LOC") + ") : ");
		dto.setCityId(dao.stringToInt("TBL_CITY", "CITY_ID", "CITY_LOC", sc.next()));
		
		System.out.print("전화번호 : ");
		dto.setTel(sc.next());
		
		System.out.print("부서(" + printList("TBL_BUSEO", "BUSEO_NAME") + ") : ");
		dto.setBuseoId(dao.stringToInt("TBL_BUSEO", "BUSEO_ID", "BUSEO_NAME", sc.next()));
		
		System.out.print("직위(" + printList("TBL_JIKWI", "JIKWI_NAME") + ") : ");
		String jikwiTemp = sc.next();
		dto.setJikwiID(dao.stringToInt("TBL_JIKWI", "JIKWI_ID", "JIKWI_NAME", jikwiTemp));
		
		System.out.print("기본급(최소 "+ dao.stringToInt("TBL_JIKWI", "MIN_BASICPAY", "JIKWI_NAME", jikwiTemp) +"원 이상) : ");
		dto.setBasicPay(sc.nextInt());
		
		System.out.print("수당 : ");
		dto.setSudang(sc.nextInt());
		
		int check = dao.insert(dto);
		if (check>0)
		{
			System.out.println("직원정보 입력 완료!");
		}
		System.out.println();
	}
	private String printList(String table, String column)
	{
		String result="";
		for (String item : dao.getList(table, column))
		{
			result = result + item + "/";
		}
		return result;
	}

	// 전체 출력
	public void selectAll()
	{	
		System.out.println();
		System.out.println("직원 전체 출력");
		Scanner sc = new Scanner(System.in);
		int choice;
		
		System.out.println("1. 사번 정렬");
		System.out.println("2. 이름 정렬");
		System.out.println("3. 부서 정렬");
		System.out.println("4. 직위 정렬");
		System.out.println("5. 급여 내림차순 정렬");
		System.out.print(">> 선택(1~5, -1 종료) : ");
		
		choice = sc.nextInt();
		
		// 정렬
		switch (choice)
		{
		case 1:
			selectAllPrint("EMP_ID");
			break;
		case 2:
			selectAllPrint("EMP_NAME");
			break;
		case 3:
			selectAllPrint("BUSEO_NAME");
			break;
		case 4:
			selectAllPrint("JIKWI_NAME");
			break;
		case 5:
			selectAllPrint("PAY DESC");
			break;
		case -1:
			return;
		}
	}
	// 전체 출력 헬퍼 메소드
	private void selectAllPrint(String orderBy)
	{	
		System.out.println();
		System.out.println("전체 인원 : " + dao.count());
		System.out.println("--------------------------------------------------------------------------------------------------");
		System.out.println("사번  이름     주민번호      입사일   지역    전화번호    부서  직위   기본급    수당      급여");
		System.out.println("--------------------------------------------------------------------------------------------------");
		for (MemberDTO dto : dao.selectAll(orderBy))
		{
			System.out.printf("%4d %3s %14s %10s %2s %13s %3s %2s %8d %8d %10d\n", dto.getEmpId(), dto.getEmpName(), dto.getSsn(), dto.getIbsadate().substring(0, 10), dto.getCityLoc(), dto.getTel(), dto.getBuseoName(), dto.getJikwiName(), dto.getBasicPay(), dto.getSudang(), dto.getPay());
		}
		System.out.println();
	}
	
	// 검색 출력
	public void select()
	{
		System.out.println();
		Scanner sc = new Scanner(System.in);
		int choice;
		System.out.println("1. 사번 검색");
		System.out.println("2. 이름 검색");
		System.out.println("3. 부서 검색");
		System.out.println("4. 직위 검색");
		System.out.print(">> 선택(1~4, -1 종료) : ");
		choice = sc.nextInt();
		System.out.println();
		switch (choice)
		{
		case 1:
			System.out.print("검색할 사번을 입력해 주세요 : ");
			selectPrint("EMP_ID");
			break;
		case 2:
			System.out.print("검색할 이름을 입력해 주세요 : ");
			selectPrint("EMP_NAME");
			break;
		case 3:
			System.out.print("검색할 부서를 입력해 주세요("+ printList("TBL_BUSEO", "BUSEO_NAME") +") : ");
			selectPrint("BUSEO_NAME");
			break;
		case 4:
			System.out.print("검색할 직급을 입력해 주세요("+ printList("TBL_JIKWI", "JIKWI_NAME") +") : ");
			selectPrint("JIKWI_NAME");
			break;
		case -1:
			return;
		}
		System.out.println();
	}
	
	// 검색 출력 헬퍼 메서드
	private void selectPrint(String selectBy)
	{	
		Scanner sc = new Scanner(System.in);
		String input = sc.next();
		System.out.println();
		System.out.println("--------------------------------------------------------------------------------------------------");
		System.out.println("사번  이름     주민번호      입사일   지역    전화번호    부서  직위   기본급    수당      급여");
		System.out.println("--------------------------------------------------------------------------------------------------");
		
		for (MemberDTO dto : dao.select(selectBy,input))
			System.out.printf("%4d %3s %14s %10s %2s %13s %3s %2s %8d %8d %10d\n", dto.getEmpId(), dto.getEmpName(), dto.getSsn(), dto.getIbsadate().substring(0, 10), dto.getCityLoc(), dto.getTel(), dto.getBuseoName(), dto.getJikwiName(), dto.getBasicPay(), dto.getSudang(), dto.getPay());
	}
	
	// 수정
	public void update()
	{	
		System.out.println();
		Scanner sc = new Scanner(System.in);
		int empId;
		String inputTemp;
		System.out.print("수정할 직원의 사번을 입력하세요 : ");
		MemberDTO dto = dao.select("EMP_ID", sc.next()).get(0);
		System.out.println();
		System.out.println("------------------------------------선택한 사원의 현재 정보---------------------------------------");
		System.out.println("사번  이름     주민번호      입사일   지역    전화번호    부서  직위   기본급    수당      급여");
		System.out.println("--------------------------------------------------------------------------------------------------");
		System.out.printf("%4d %3s %14s %10s %2s %13s %3s %2s %8d %8d %10d\n", dto.getEmpId(), dto.getEmpName(), dto.getSsn(), dto.getIbsadate().substring(0, 10), dto.getCityLoc(), dto.getTel(), dto.getBuseoName(), dto.getJikwiName(), dto.getBasicPay(), dto.getSudang(), dto.getPay());
		System.out.println("--------------------------------------------------------------------------------------------------");
		System.out.println();
		System.out.println();
		System.out.print("이름 (유지 → P입력) : ");
		inputTemp = sc.next();
		if (!inputTemp.equals("P"))
			dto.setEmpName(inputTemp);
		
		System.out.print("지역(" + printList("TBL_CITY", "CITY_LOC") + ") (유지 → P입력) : ");
		inputTemp = sc.next();
		if (!inputTemp.equals("P"))
			dto.setCityId(dao.stringToInt("TBL_CITY", "CITY_ID", "CITY_LOC", inputTemp));
		
		System.out.print("전화번호 (유지 → P입력) : ");
		inputTemp = sc.next();
		if (!inputTemp.equals("P"))
			dto.setTel(inputTemp);
		
		System.out.print("부서(" + printList("TBL_BUSEO", "BUSEO_NAME") + ") (유지 → P입력) : ");
		inputTemp = sc.next();
		if (!inputTemp.equals("P"))
			dto.setBuseoId(dao.stringToInt("TBL_BUSEO", "BUSEO_ID", "BUSEO_NAME",inputTemp));
		
		System.out.print("직위(" + printList("TBL_JIKWI", "JIKWI_NAME") + ") (유지 → P입력) : ");
		inputTemp = sc.next();
		String jikwiTemp = "";
		if (!inputTemp.equals("P"))
		{
			dto.setJikwiID(dao.stringToInt("TBL_JIKWI", "JIKWI_ID", "JIKWI_NAME", inputTemp));
			jikwiTemp = inputTemp;
		}
		else
			jikwiTemp = dto.getJikwiName();
		
		System.out.print("기본급(최소 "+ dao.stringToInt("TBL_JIKWI", "MIN_BASICPAY", "JIKWI_NAME", jikwiTemp) +"원 이상) (유지 → P입력) : ");
		inputTemp = sc.next();
		if (!inputTemp.equals("P"))
			dto.setBasicPay(Integer.parseInt(inputTemp));
		
		System.out.print("수당 (유지 → P입력) : ");
		inputTemp = sc.next();
		if (!inputTemp.equals("P"))
			dto.setSudang(Integer.parseInt(inputTemp));
		
		int check = dao.update(dto);
		
		if (check>0)
			System.out.println("업데이트 완료!");
		
		System.out.println();
	}
	
	// 삭제
	public void delete()
	{
		Scanner sc = new Scanner(System.in);
		System.out.println();
		
		System.out.print("삭제할 직원의 사번을 입력해 주세요 : ");
		int check = dao.delete(sc.nextInt());
		
		if (check>0)
			System.out.println("삭제가 완료되었습니다!");
		
		System.out.println();
	}
	
	// 데이터베이스 연결 해제
	public void close()
	{
		dao.close();
	}
}
