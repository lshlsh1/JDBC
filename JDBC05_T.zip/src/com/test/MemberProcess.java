/*=============================================
	MemberProcess.java
	- 콘솔 기반 서브 메뉴 입출력 전용 클래스
=============================================*/

package com.test;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;

public class MemberProcess
{
	private MemberDAO dao;

	// 생성자 정의
	public MemberProcess()
	{
		dao = new MemberDAO();
	}

	// 직원 정보 입력 메소드 정의
	public void memberInsert()
	{
		Scanner sc = new Scanner(System.in);

		try
		{
			// 데이터베이스 연결
			dao.connection();

			// 지역 리스트 구성
			ArrayList<String> citys = dao.searchCity();
			StringBuilder cityStr = new StringBuilder();	//String을 사용하면 비효율적이므로
			
			for (String city : citys)
			{
				cityStr.append(city + "/");
				
			}
			// 부서 리스트 구성
			ArrayList<String> buseo = dao.searchBuseo();
			StringBuilder buseoStr = new StringBuilder();
			
			for (String b : buseo)
			{
				buseoStr.append(b+"/");
			}
			// 직위 리스트 구성
			ArrayList<String> jikwi = dao.searchJikwi();
			StringBuilder jikwiStr = new StringBuilder();
			for (String j : jikwi)
			{
				jikwiStr.append(j+"/");
				
			}
			
			//사용자에게 보여지는 화면 처리
			System.out.println("직원 정보 입력 -------------------------------------------------------");
			System.out.print("이름 : ");
			String empName = sc.next();
			if (empName.equals("."))
				return;
			
			System.out.print("주민번호(yymmdd-nnnnnnn) : ");
			String ssn = sc.next();
			
			System.out.print("입사일(yyyy-mm-dd) : ");
			String ibsaDate = sc.next();
			
			System.out.printf("지역(%s) : ", cityStr.toString());
			String cityLoc = sc.next();
						
			System.out.print("전화번호 : ");
			String tel = sc.next();
			
			System.out.printf("부서(%s) : ", buseoStr.toString());
			String buseoName = sc.next();
			
			System.out.printf("직위(%s) : ", jikwiStr.toString());
			String jikwiName = sc.next();
				
			// 최소 기본급 구성
			System.out.printf("기본급(최소 %d원 이상) : ", dao.searchBasicPay(jikwiName));
			int basicPay = sc.nextInt();
			
			System.out.print("수당 : ");
			int suDang = sc.nextInt();
			System.out.println("");
			
			//MemberDTO 에 대한 인스턴스 생성
			MemberDTO dto = new MemberDTO();
			dto.setEmpName(empName);
			dto.setSsn(ssn);
			dto.setIbsaDate(ibsaDate);
			dto.setCityLoc(cityLoc);
			dto.setTel(tel);
			dto.setBuseoName(buseoName);
			dto.setJikwiName(jikwiName);
			dto.setBasicpay(basicPay);
			dto.setSudang(suDang);
			
			int result = dao.add(dto);
			
			if (result>0)
			{
				System.out.println("");				
				System.out.println("직원 정보 입력 완료~!!!!!");
			}
			System.out.println("-----------------------------------------------------------------------");

		} catch (Exception e)
		{
			System.out.println(e.toString());
		}
		finally
		{
			try
			{
				dao.close();
				
			} catch (Exception e)
			{
				System.out.println(e.toString());
			}
		}
	}

	// 직원 전체 출력 메소드 정의
	public void memberLists()
	{
		Scanner sc = new Scanner(System.in);
		
		//서브메뉴 출력
		System.out.println("1. 사번 정렬");
		System.out.println("2. 이름 정렬");
		System.out.println("3. 부서 정렬");
		System.out.println("4. 직위 정렬");
		System.out.println("5. 급여 내림차순 정렬");
		System.out.print(">> 선택(1~5, -1 종료) : ");
		
		String menuStr = sc.next();
		
		try
		{
			int menu = Integer.parseInt(menuStr);
			if(menu == -1)
				return;
			
			String key = "";
			switch(menu)
			{
				case 1 : key = "EMP_ID"; break;
				case 2 : key = "EMP_NAME"; break;
				case 3 : key = "BUSEO_NAME"; break;
				case 4 : key = "JIKWI_NAME"; break;
				case 5 : key = "PAY DESC"; break;
			}

			
			//데이터베이스 연결
			dao.connection();
			
			//직원 리스트 출력
			System.out.println("");
			System.out.printf("전체 인원 : %d명\n", dao.memeberCount());
			System.out.println("사번  이름     주민번호      입사일   지역    전화번호    부서  직위   기본급    수당      급여");
			ArrayList<MemberDTO> memList = dao.lists(key);
			for (MemberDTO memberDTO : memList)
			{
				System.out.printf("%4d %4s %4s %4s %4s %4s %4s %4s %4d %4d\n"
						, memberDTO.getEmpId(), memberDTO.getEmpName(), memberDTO.getSsn(), memberDTO.getIbsaDate(), memberDTO.getCityLoc(), memberDTO.getTel(), memberDTO.getBuseoName(), memberDTO.getEmpName(),memberDTO.getBasicpay(),memberDTO.getSudang(),memberDTO.getPay());
			}
			
		} catch (Exception e)
		{
			System.out.println(e.toString());
		}
		finally
		{
			try
			{
				dao.close();
				
			} catch (Exception e2)
			{
				System.out.println(e2.toString());
			}
		}
				
	}
	

	// 직원 검색 출력 메소드 정의
	public void memberSearch()
	{
		Scanner sc = new Scanner(System.in);
		
		//서브메뉴 구성
		System.out.println("1. 사번 검색");
		System.out.println("2. 이름 검색");
		System.out.println("3. 부서 검색");
		System.out.println("4. 직위 검색");
		System.out.print(">> 선택(1~4, -1 종료) : ");
		String menuStr = sc.next();
				
		try
		{
			int menu = Integer.parseInt(menuStr);
			if (menu==-1)
				return;
			
			String key = "";
			String value = "";
					
			switch (menu)
			{
				case 1 : key = "EMP_ID";
					System.out.print("검색할 사원번호 입력 : ");
					value = sc.next();
					break;
				case 2 : key = "EMP_NAME";
					System.out.print("검색할 이름 입력 : ");
					value = sc.next();
					break;
					
				case 3 : key = "BUSEO_NAME";
					System.out.print("검색할 부서명 입력 : ");
					value = sc.next();
					break;
					
				case 4 : key = "JIKWI_NAME";
					System.out.print("검색할 직위 입력 : ");
					value = sc.next();
			}
			
			//데이터 베이스 연결
			dao.connection();
			
			//검색 결과 출력
			System.out.println("");
			System.out.printf("전체 인원 : %d명\n", dao.memberCount(key, value));
			System.out.println("사번  이름     주민번호      입사일   지역    전화번호    부서  직위   기본급    수당      급여");
			ArrayList<MemberDTO> memList = dao.searchlists(key, value);
			for (MemberDTO memberDTO : memList)
			{
				System.out.printf("%4d %4s %4s %4s %4s %4s %4s %4s %4d %4d\n"
						, memberDTO.getEmpId(), memberDTO.getEmpName(), memberDTO.getSsn(), memberDTO.getIbsaDate(), memberDTO.getCityLoc(), memberDTO.getTel(), memberDTO.getBuseoName(), memberDTO.getBasicpay(),memberDTO.getSudang(),memberDTO.getPay());
			}
			
			
		} catch (Exception e)
		{
			System.out.println(e.toString());
		}
		finally
		{
			try
			{
				dao.close();
				
			} catch (Exception e2)
			{
				System.out.println(e2.toString());
			}
		}	
	}

	// 직원 정보 출력 메소드 정의
	
	public void memeberUpadete() throws ClassNotFoundException, SQLException 
	{
		Scanner sc = new Scanner(System.in);
		
		dao.connection();
		
		try
		{
			
			//지역 리스트 구성
			ArrayList<String> citys = dao.searchCity();
			StringBuilder cityStr = new StringBuilder();	//String을 사용하면 비효율적이므로
			
			for (String city : citys)
			{
				cityStr.append(city + "/");
				
			}
			// 부서 리스트 구성
			ArrayList<String> buseo = dao.searchBuseo();
			StringBuilder buseoStr = new StringBuilder();
			
			for (String b : buseo)
			{
				buseoStr.append(b+"/");
			}
			// 직위 리스트 구성
			ArrayList<String> jikwi = dao.searchJikwi();
			StringBuilder jikwiStr = new StringBuilder();
			for (String j : jikwi)
			{
				jikwiStr.append(j+"/");
				
			}
			
			
			
			//수정할 대상 입력받기
			System.out.print("수정할 직원의 사원번호 입력 : ");
			String value = sc.next();
			
			/*
			try 
			{
				
			
			// 데이터베이스 연결
			ArrayList<MemberDTO> members = dao.searchlists("EMP_ID", value);
			
			if (members.size()>0)
			{
							
				MemberDTO mMember = members.get(0);
				int mEmpid = mMember.getEmpId();
				String mEmpName = mMember.getEmpName();
				String mSsn = mMember.getSsn();
				String mIbsaDate = mMember.getIbsaDate();
				String mCityLoc = mMember.getCityLoc();
				String mTel = mMember.getTel();
				String mBusoName = mMember.getBuseoName();
				String mjikwiName = mMember.getJikwiName();
				int mBasicPay = mMember.getBasicpay();
				int mSudang = mMember.getSudang();
				
				System.out.println();
				System.out.println("직원 정보 수정 ----------------------------------------");
				System.out.printf("기존 이름 : %s%n", mEmpName);
				System.out.print("수정 이름 :");
				String empName = sc.next();
				if (empName.equals("-"))
					empName=mEmpName;
				
				System.out.printf("기존 주민번호 : %s%n", mSsn);
				System.out.print("수정 주민번호" );
				System.out.println("-------------------------------------------------------");
				
				//:
					
				System.out.printf("기존 지역 : %s%n", mCityLoc);
				System.out.printf("수정 지역(%s) : ", citystr);
				String cityLoc = sc.next();
				if (cityLoc.equals("-"))
					cityLoc = mCityLoc;
				
				System.out.printf("기존 전화번호 : %s%n", mTel);
				System.out.print("수정 전화번호 : ");
				String tel = sc.next();
				if (tel.equals("-"))
					tel = mTel;
				
				//:
				
				System.out.println("기존 기본급 : %d%n", mBasicPay);
				System.out.println("수정 기본급(최소 %d원 이상) : ", dao.searchBasicPay(jikwiName));
				String basicPayStr = sc.next();
				int basicPay=0;
				if (basicPayStr.equals("-"))
					basicPay = mBasicPay;
				else
					basicPay = Integer.parseInt(basicPayStr)
					
				//:
					
				MemberDTO member = new MemberDTO();
				member.setEmpId(mempId);
				member.setEmpName(empName);
				member.setSsn(ssn);
				member.setIbsaDate(ibsaDate);
				member.setCityLoc(cityLoc);
				member.setTel(tel);
				member.setBuseoName(buseoName);
				member.setJikwiName(jikwiName);
				member.setBasicpay(basicpay);
				member.setSudang(sudang);
				
				int result = dao.modify(dto);
				if(result > 0)
					System.out.println("직원 정보 수정 완료~!!!");
				
				System.out.println("-----------------------------------------------------");
				
			}else
			{
				System.out.println("수정 대상을 검색하지 못했습니다.");
			}
			*/
			
			// 승희 ver
			
			ArrayList<MemberDTO> members = dao.searchlists("EMP_ID", value);
			MemberDTO dto = dao.searchlists("EMP_ID", value).get(0);
			
			System.out.printf("기존 이름 : %s\n", dto.getEmpName());
			System.out.print("수정 이름 : ");
			String empName = sc.next();
			if (empName.equals("-"))
				dto.setEmpName(dto.getEmpName());
			else
				dto.setEmpName(empName);

			System.out.printf("기존 주민번호(yymmdd-nnnnnnn) : %s\n", dto.getSsn());
			System.out.print("수정 주민번호 (yymmdd-nnnnnnn) : ");
			String ssn = sc.next();
			if (ssn.equals("-"))
				dto.setSsn(dto.getSsn());
			else
				dto.setSsn(ssn);
				
			
			System.out.printf("기존 입사일(yyyy-mm-dd) : %s\n", dto.getIbsaDate());
			System.out.print("수정 입사일(yyyy-mm-dd) : ");
			String ibsadate = sc.next();
			if (ibsadate.equals("-"))
				dto.setIbsaDate(dto.getIbsaDate());
			else
				dto.setIbsaDate(ibsadate);
			
			System.out.printf("기존 지역(%s) : %s\n", cityStr.toString() ,dto.getCityLoc()); //
			System.out.printf("수정 지역(%s) : ", cityStr.toString());
			String cityloc = sc.next();
			if (cityloc.equals("-"))
				dto.setCityLoc(dto.getCityLoc());
			else 
				dto.setCityLoc(cityloc);
			
			System.out.printf("기존 전화번호 : %s\n", dto.getTel());
			System.out.print("수정 전화번호 : ");
			String tel = sc.next();
			if (tel.equals("-"))
				dto.setTel(dto.getTel());
			else 
				dto.setTel(tel);
			
			System.out.printf("기존 부서(%s) : %s\n", buseoStr.toString() , dto.getBuseoName()); 
			System.out.printf("수정 부서(%s) : ", buseoStr.toString()); 
			String buseoname = sc.next();
			if (buseoname.equals("-"))
				dto.setBuseoName(dto.getBuseoName());
			else
				dto.setBuseoName(buseoname);
			
			System.out.printf("기존 직위(%s) : %s\n", jikwiStr.toString(), dto.getJikwiName());
			System.out.printf("수정 직위(%s) : ", jikwiStr.toString());
			String jikwiname = sc.next();
			if(jikwiname.equals("-"))
			{
				dto.setJikwiName(dto.getJikwiName());
			}
			else
			{
				dto.setJikwiName(jikwiname);
			}
			
			System.out.printf("기존 기본급 : %s\n", dto.getBasicpay());
			System.out.printf("수정 기본급 (최소 %s 이상) : ", dao.searchBasicPay(jikwiname));
			String basicpayStr = sc.next();
			int basicpay=0;
			if (basicpayStr.equals("-"))
				dto.setBasicpay(dto.getBasicpay());
			else
				basicpay = Integer.parseInt(basicpayStr);
				dto.setBasicpay(basicpay);
			
			System.out.printf("기존 수당 : %s\n", dto.getSudang());
			System.out.print("수정 수당 : ");
			String sudangStr = sc.next();
			int sudang =0;
			if (sudangStr.equals("-"))
				dto.setSudang(dto.getSudang());
			else
				sudang = Integer.parseInt(sudangStr);
				dto.setSudang(sudang);
			
			int check = dao.modify(dto);
			
			if (check>0)
				System.out.println("업데이트 완료!");
			
			System.out.println();
		
			
			
		} catch (Exception e)
		{
			System.out.println(e.toString());
		}
		finally
		{
			try
			{
				dao.close();
				
			} catch (Exception e2)
			{
				System.out.println(e2.toString());
			}
		
		}
	}

	// 직원 정보 삭제 메소드 정의
	public void memberDelet()
	{
		Scanner sc = new Scanner(System.in);
		
		try
		{
			System.out.print("삭제할 직원의 사원번호 입력 :");
			String value= sc.next();
			
			dao.connection();
			
			dao.searchlists("EMP_ID", value);
			
			ArrayList<MemberDTO> members = dao.searchlists("EMP_ID", value);
			
			if(members.size() > 0)
			{
				
				for (MemberDTO memberDTO : members)
				{
					System.out.printf("%4d %4s %4s %4s %4s %4s %4s %4s %4d %4d\n"
							, memberDTO.getEmpId(), memberDTO.getEmpName(), memberDTO.getSsn(), memberDTO.getIbsaDate(), memberDTO.getCityLoc(), memberDTO.getTel(), memberDTO.getBuseoName(), memberDTO.getBasicpay(),memberDTO.getSudang(),memberDTO.getPay());
					
				}
				System.out.print("정말 삭제하시겠습니까?(Y/N)");
				String response = sc.next();
				if (response.equals("Y") || response.equals("y"))
				{
					int result = dao.remove(Integer.parseInt(value));
					if (result > 0)
						System.out.println("직원정보가 정상적으로 삭제되었습니다.");
				}	
			}else
			{
				System.out.println("직원정보가 검색되지 않았습니다.");
			}						
			
		} catch (Exception e)
		{
			System.out.println(e.toString());
		}
		finally
		{
			try
			{
				dao.close();
				
			} catch (Exception e2)
			{
				System.out.println(e2.toString());
			}
		}
	}
}
