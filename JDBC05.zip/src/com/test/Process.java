package com.test;

import java.sql.SQLException;
import java.util.Scanner;

public class Process
{
	private MemberDAO dao;
	
	public Process()
	{
		dao = new MemberDAO();
	}
	
	//1. 직원 정보 입력
	
	public void junboInsert() 
	{
		try
		{
			dao.connection();
			Scanner sc = new Scanner(System.in);
			
			
			do
			{
				System.out.println("직원 정보 입력 -------------------------------------------------------");
				System.out.print("이름 : ");
				String emp_name = sc.next();
				if (emp_name.equals("."))
					break;
				
				System.out.print("주민번호(yymmdd-nnnnnnn) : ");
				String ssn = sc.next();
				
				System.out.print("입사일(yyyy-mm-dd) : ");
				String ibsadate = sc.next();
				
				System.out.print("지역("+ printList("TBL_CITY", "CITY_LOC")+") : ");
				String city_loc = sc.next();
				int city_id = dao.city(city_loc);
				
				System.out.print("전화번호 : ");
				String tel = sc.next();
				
				System.out.print("부서("+ printList("TBL_BUSEO","BUSEO_NAME")+") : ");
				String buseo_name = sc.next();
				int buseo_id = dao.buseo(buseo_name);
				
				System.out.print("직위("+ printList("TBL_JIKWI","JIKWI_NAME")+") : ");
				String jikwi_name = sc.next();
				int jikwi_id = dao.jikwi(jikwi_name);
				int basicpayN = dao.basicpay(jikwi_id);
					
				System.out.printf("기본급(최소 %d원 이상) : ", basicpayN);
				int basicpay = sc.nextInt();
				System.out.println("수당 : ");
				int sudang = sc.nextInt();
				
			
				MemberDTO dto = new MemberDTO();
				dto.setEmp_name(emp_name);
				dto.setSsn(ssn);
				dto.setIbsadate(ibsadate);
				dto.setCity_id(city_id);
				dto.setTel(tel);
				dto.setBuseo_id(buseo_id);
				dto.setJikwi_id(jikwi_id);
				dto.setBasicpay(basicpay);
				dto.setSudang(sudang);
				
				int result = dao.add(dto);
				
				if (result>0)
				{
					System.out.println("");				
					System.out.println("직원 정보 입력 완료~!!!!!");
					System.out.println("-----------------------------------------------------------------------");
				}
				
			} while (true);
			
			
		} catch (Exception e)
		{
			System.out.println(e.toString());
		}
		
	}

	private String printList(String table, String column)
	{
		String result="";
		for (String item : dao.getList(table, column))
		{
			result = result + item + "/";
		}
		return result;
	}

	
	//2. 직원 전체 출력
	//2-1 사번 정렬
	public void printsabun()
	{
		try
		{
			dao.connection();
			int count = dao.count();
			
			System.out.println();
			System.out.printf("전체인원 : %d명\n", count);
			System.out.println("사번	이름	주민번호	입사일	지역	전화번호	부서 	직위	기본급	수당	급여");
			
			for (MemberDTO dto : dao.lists())
			{
				System.out.printf("%4s %4s %4d %4d %4d %4d %4f %4d\\n"
						, dto.getEmp_id(), dto);
		
			}
			
		} catch (Exception e)
		{
			System.out.println(e.toString());
		}
	}
	//2-2 이름 정렬
	//2-3 부서 정렬
	//2-4 직위 적렬
	//2-5 급여 내림차수 정렬
	//3. 직원 검색 출력
	//3-1 사번 검색
	//3-2 이름 검색
	//3-3 부서 검색
	//3-4 직위 검색
	//4. 직원 정보 수정
	//5. 직원 정보 삭제
}
